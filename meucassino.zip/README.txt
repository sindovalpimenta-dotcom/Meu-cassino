Instruções para publicar o site:

1. Faça login na sua hospedagem ou GitHub.
2. Para hospedagem: acesse a pasta public_html e envie index.html.
3. Para GitHub Pages: crie um repositório, envie index.html, ative Pages na branch main.
4. Abra o link gerado para acessar seu site online.
